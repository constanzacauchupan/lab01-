package mccc.lab01;
import java.util.Scanner;
public class Lab01 {
    public static void main(String[] args) {
    int bandera = 1;
    while (bandera == 1){
        Scanner leer = new Scanner(System.in);
        /* Se pide el valor del dolar y se crea el objeto */
        System.out.println("Ingresa el valor del Dolar");
        Moneda dolar = new Moneda(leer.nextFloat(),"Dolar");
        /* Se pide el valor del euro y se crea el objeto */
        System.out.println("Ingresa el valor del Euro");
        Moneda euro = new Moneda(leer.nextFloat(),"Euro");
        /* Se pide el valor del peso argentino y se crea el objeto */
        System.out.println("Ingresa el valor del Peso Argentino");
        Moneda pesoargentino = new Moneda(leer.nextFloat(),"Peso Argentino");
        /* Se pide el monto a convertir */
        System.out.println("Ingresa el monto a convertir");
        float montoCLP = leer.nextFloat();
        /* Se calcula el monto en las distintas monedas */
        Calculadora dolarAclp = new Calculadora(montoCLP,dolar.getValor(),0);
        System.out.println("$"+montoCLP + " pesos chilenos corresponden a "+dolarAclp.calculo()+" Dólares");
        Calculadora clpAeuro = new Calculadora(montoCLP,euro.getValor(),0);
        System.out.println("$"+montoCLP + " pesos chilenos corresponden a "+clpAeuro.calculo()+" Euros");
        Calculadora paAclp = new Calculadora(montoCLP,pesoargentino.getValor(),0);
        System.out.println("$"+montoCLP + " pesos chilenos corresponden a "+paAclp.calculo()+" Pesos Argentinos");
        System.out.println("Presiona 1 para continuar, 0 para salir");
        }
    }
}