package mccc.lab01;
public class Calculadora {
    private float montoCLP;
    private float valorMoneda;
    private float valorFinal;

    public Calculadora(float montoCLP, float valorMoneda, float valorFinal) {
        this.montoCLP = montoCLP;
        this.valorMoneda = valorMoneda;
        this.valorFinal = valorFinal;
    }

    public float getMontoCLP() {
        return montoCLP;
    }

    public float getValorMoneda() {
        return valorMoneda;
    }

    public float getValorFinal(){
        return valorFinal;
    }
    
    public void setMontoCLP(float montoCLP) {
        this.montoCLP = montoCLP;
    }

    public void setValorMoneda(float valorMoneda) {
        this.valorMoneda = valorMoneda;
    }

    public void SetValorFinal(float valorFinal){
        this.valorFinal = valorFinal;
    }
    
    float calculo(){
    this.valorFinal = this.montoCLP / this.valorMoneda;
    return this.valorFinal;
    }
}

