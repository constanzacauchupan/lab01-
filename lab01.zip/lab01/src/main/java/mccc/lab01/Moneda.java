package mccc.lab01;
public class Moneda {
    private float valor;
    private String nombre;

    public Moneda(float valor, String nombre) {
        this.valor = valor;
        this.nombre = nombre;
    }

    public float getValor() {
        return valor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
}
